package Autobus;
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class main extends JFrame{
	
	public static List<PasseggeroFrame.Passeggero> passeggeri = new ArrayList<>();
    public static List<AutistaFrame.Autista> autisti = new ArrayList<>();
    
    public static int PasseggeriMax = 2;
    public static int AutistiMax = 2;

    public static void main(String[] args) {

        JFrame frame = new JFrame();
        frame.setTitle("Gestione Atobus");
        frame.setSize(400, 200);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        JButton passeggeroBtn = new JButton("Inserisci Passeggero");
        JButton autistaBtn = new JButton("Inserisci Autista");

        passeggeroBtn.addActionListener(e -> new PasseggeroFrame(passeggeri));
        autistaBtn.addActionListener(e -> new AutistaFrame(autisti));

        JPanel topPanel = new JPanel();
        topPanel.add(passeggeroBtn);
        topPanel.add(autistaBtn);

        JButton visualizzaBtn = new JButton("Visualizza Tutti");
        visualizzaBtn.addActionListener(e -> new VisualizzaArray(passeggeri, autisti));

        frame.add(topPanel, BorderLayout.CENTER);
        frame.add(visualizzaBtn, BorderLayout.SOUTH);

        frame.setVisible(true);
    }

}
