package Autobus;
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class PasseggeroFrame extends JFrame{
	
	public static class Passeggero extends Persona{
		
		protected String destinazione;
		protected boolean bagaglio;

        public Passeggero(String nome, String cognome, String codiceFiscale, String destinazione, boolean bagaglio) {
        	super(nome, cognome, codiceFiscale);
        	this.destinazione = destinazione;
        	this.bagaglio = bagaglio;
        }

        @Override
        public String getInfo() {
        	
        	String tmp;
        	
        	if(bagaglio) tmp = "con";
        	else tmp = "senza";
        	
    		return "Il Passeggero " + nome + " " + cognome + ", con codice fiscale pari a " + codiceFiscale + ", e' diretto a " + destinazione
    				+ " " + tmp + " bagagli";
    	}
    }
	
	public PasseggeroFrame(List<Passeggero> passeggeri) {
        JFrame frame = new JFrame();

        frame.setTitle("Inserisci Passeggero");
        frame.setSize(400, 250);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new GridLayout(6, 2, 5, 5));

        JTextField nomeField = new JTextField();
        JTextField cognomeField = new JTextField();
        JTextField cfField = new JTextField();
        JTextField destinazioneField = new JTextField();

        JLabel bagaglioLabel = new JLabel("Bagaglio:");
        JComboBox<String> bagaglioCombo = new JComboBox<>(new String[]{"Sì", "No"});

        JButton salvaBtn = new JButton("Salva");

        panel.add(new JLabel("Nome:"));
        panel.add(nomeField);

        panel.add(new JLabel("Cognome:"));
        panel.add(cognomeField);

        panel.add(new JLabel("Codice Fiscale:"));
        panel.add(cfField);

        panel.add(new JLabel("Destinazione:"));
        panel.add(destinazioneField);

        panel.add(bagaglioLabel);
        panel.add(bagaglioCombo);

        panel.add(new JLabel());
        panel.add(salvaBtn);

        frame.add(panel);

        salvaBtn.addActionListener(e -> {
            String nome = nomeField.getText().trim();
            String cognome = cognomeField.getText().trim();
            String codiceFiscale = cfField.getText().trim();
            String destinazione = destinazioneField.getText().trim();
            boolean bagaglio = bagaglioCombo.getSelectedItem().equals("Sì");

            if (!nome.isEmpty() && !cognome.isEmpty() && !codiceFiscale.isEmpty() && !destinazione.isEmpty()) {
                passeggeri.add(new Passeggero(nome, cognome, codiceFiscale, destinazione, bagaglio));
                JOptionPane.showMessageDialog(frame, "Passeggero a bordo!");
                frame.dispose();
            } else {
                JOptionPane.showMessageDialog(frame, "Completa tutti i campi");
            }
        });

        frame.setVisible(true);
    }

}
