package Autobus;
import javax.swing.*;
import java.util.List;

public class VisualizzaArray extends JFrame {

    public VisualizzaArray(List<PasseggeroFrame.Passeggero> passeggeri, List<AutistaFrame.Autista> autisti) {
        setTitle("Elenco Passeggeri e Autisti");
        setSize(800, 400);
        setLocationRelativeTo(null);

        JTextArea textArea = new JTextArea();
        textArea.setEditable(false);

        textArea.append("Passeggeri:\n");
        for (PasseggeroFrame.Passeggero p : passeggeri) {
            textArea.append("- " + p.getInfo() + "\n");
        }

        textArea.append("\nAutisti:\n");
        for (AutistaFrame.Autista a : autisti) {
            textArea.append("- " + a.getInfo() + "\n");
        }

        JScrollPane scrollPane = new JScrollPane(textArea);
        add(scrollPane);

        setVisible(true);
    }
}
