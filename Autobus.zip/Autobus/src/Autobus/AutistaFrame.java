package Autobus;
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class AutistaFrame extends JFrame{
	
	public static class Autista extends Persona{
		
		protected String patente;
		protected int anniEsperienza;

        public Autista(String nome, String cognome, String codiceFiscale, String patente, int anniEsperienza) {
        	super(nome, cognome, codiceFiscale);
        	this.patente = patente;
        	this.anniEsperienza = anniEsperienza;
        }
        
        @Override
        public String getInfo() {
        	
        	String tmp;
        	
        	if(anniEsperienza == 0) tmp = "anni";
        	else if(anniEsperienza == 1) tmp = "anno";
        	else tmp = "anni";
        	
    		return "L'autista " + nome + " " + cognome + ", con codice fiscale pari a " + codiceFiscale + ", ha la patente " + patente
    				+ ", ed ha " + anniEsperienza + " " + tmp + " di Esperienza";
    	}
    }
	
	public AutistaFrame(List<Autista> autisti) {
        JFrame frame = new JFrame();

        frame.setTitle("Inserisci Autista");
        frame.setSize(400, 250);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new GridLayout(6, 2, 5, 5));

        JTextField nomeField = new JTextField();
        JTextField cognomeField = new JTextField();
        JTextField cfField = new JTextField();
        JTextField patenteField = new JTextField();
        JTextField esperienzaField = new JTextField();

        JButton salvaBtn = new JButton("Salva");

        panel.add(new JLabel("Nome:"));
        panel.add(nomeField);

        panel.add(new JLabel("Cognome:"));
        panel.add(cognomeField);

        panel.add(new JLabel("Codice Fiscale:"));
        panel.add(cfField);

        panel.add(new JLabel("Patente:"));
        panel.add(patenteField);

        panel.add(new JLabel("Anni di Esperienza:"));
        panel.add(esperienzaField);

        panel.add(new JLabel());
        panel.add(salvaBtn);

        frame.add(panel);

        salvaBtn.addActionListener(e -> {
            String nome = nomeField.getText().trim();
            String cognome = cognomeField.getText().trim();
            String codiceFiscale = cfField.getText().trim();
            String patente = patenteField.getText().trim();
            String esperienzaStr = esperienzaField.getText().trim();

            if (!nome.isEmpty() && !cognome.isEmpty() && !codiceFiscale.isEmpty() && !patente.isEmpty() && !esperienzaStr.isEmpty()) {
                int esperienza = Integer.parseInt(esperienzaStr);
                autisti.add(new Autista(nome, cognome, codiceFiscale, patente, esperienza));
                JOptionPane.showMessageDialog(frame, "Autista aggiunto!");
                frame.dispose();
            } else {
                JOptionPane.showMessageDialog(frame, "Completa tutti i campi!");
            }
        });

        frame.setVisible(true);
    }

}
