/**
 * 
 */
/**
 * 
 */
module Autobus {
	requires java.desktop;
}